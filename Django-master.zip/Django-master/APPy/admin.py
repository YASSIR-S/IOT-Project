
from django.contrib import admin
# Register your models here.
from APPy.models import Dht
admin.site.register(Dht)
